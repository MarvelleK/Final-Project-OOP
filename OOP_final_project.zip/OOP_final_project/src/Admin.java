import java.util.Scanner;

public class Admin extends User {
    private int adminId;
    
    public Admin(int adminId, String name) {
        super(name);
        this.adminId = adminId;
    }
    
    public void accessLibrary(Library library, Scanner scanner) {
        System.out.println("\nLog in as Admin: " + name + " (ID: " + adminId + ")");
        
        while (true) {
            System.out.println("\n=== Admin Menu ===");
            System.out.println("1. Add Book");
            System.out.println("2. View All Books");
            System.out.println("3. Update Book");
            System.out.println("4. Delete Book");
            System.out.println("5. Search Book");
            System.out.println("6. Sort Books");
            System.out.println("7. Logout");
            System.out.print("Choose option: ");
            
            int choice = getIntInput(scanner);
            
            switch (choice) {
                case 1 -> library.addBook(scanner);
                case 2 -> library.viewAllBooks();
                case 3 -> updateBook(library, scanner);
                case 4 -> deleteBook(library, scanner);
                case 5 -> library.searchBook(scanner);
                case 6 -> library.sortBooks(scanner);
                case 7 -> {
                    System.out.println("Logged out");
                    return;
                }
                default -> System.out.println("Invalid choice!");
            }
        }
    }
    
    private void updateBook(Library library, Scanner scanner) {
        System.out.print("Enter Book ID to update: ");
        int bookId = getIntInput(scanner);
        
        System.out.print("Enter new title (press Enter to keep current): ");
        String newTitle = scanner.nextLine();
        
        System.out.print("Enter new author (press Enter to keep current): ");
        String newAuthor = scanner.nextLine();
        
        boolean success = library.updateBook(bookId, newTitle, newAuthor);
        if (success) {
            System.out.println("Book updated successfully!");
        } else {
            System.out.println("Failed to update book!");
        }
    }
    
    private void deleteBook(Library library, Scanner scanner) {
        System.out.print("Enter Book ID to delete: ");
        int bookId = getIntInput(scanner);
        
        boolean success = library.deleteBook(bookId);
        if (success) {
            System.out.println("Book deleted successfully!");
        } else {
            System.out.println("Failed to delete book!");
        }
    }
    
    public void codBlock(Library library, Book book) {
        System.out.println("Admin " + name + " is blocking book: " + book.getTitle());
    }
    
    private int getIntInput(Scanner scanner) {
        try {
            int value = scanner.nextInt();
            scanner.nextLine();
            return value;
        } catch (Exception e) {
            scanner.nextLine();
            return -1;
        }
    }
}