import java.util.*;

public class Library {
    private List<Book> books;
    private int nextBookId = 1001;
    
    public Library() {
        books = new ArrayList<>();
    }
    
    private int getNextBookId() {
        return nextBookId++;
    }
    
    
    public void addBook(Scanner scanner) {
        System.out.println("\n=== Add New Book ===");
        
        int bookId = getNextBookId();
        System.out.println("Book ID will be: " + bookId);
        
        System.out.print("Enter Title: ");
        String title = scanner.nextLine();
        
        System.out.print("Enter Author: ");
        String author = scanner.nextLine();
        
        Book newBook = new Book(bookId, title, author);
        books.add(newBook);
        System.out.println("Book added successfully with ID: " + bookId);
    }
    
    public void viewAllBooks() {
        System.out.println("\n=== All Books ===");
        if (books.isEmpty()) {
            System.out.println("No books in the library.");
            return;
        }
        
        for (int i = 0; i < books.size(); i++) {
            System.out.print((i + 1) + ". ");
            books.get(i).displayInfo();
        }
    }
    
    public void viewAvailableBooks() {
        System.out.println("\n=== Available Books ===");
        boolean found = false;
        
        for (Book book : books) {
            if (book.isAvailable()) {
                book.displayInfo();
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No books available at the moment.");
        }
    }
    
    public boolean updateBook(int bookId, String newTitle, String newAuthor) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                if (!newTitle.isEmpty()) {
                    book.setTitle(newTitle);
                }
                if (!newAuthor.isEmpty()) {
                    book.setAuthor(newAuthor);
                }
                return true;
            }
        }
        return false;
    }
    
    public boolean deleteBook(int bookId) {
        Book bookToRemove = null;
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                bookToRemove = book;
                break;
            }
        }
        
        if (bookToRemove != null && bookToRemove.isAvailable()) {
            books.remove(bookToRemove);
            return true;
        }
        return false;
    }
    
    public void searchBook(Scanner scanner) {
        System.out.println("\n=== Search Book ===");
        System.out.println("1. Search by Title");
        System.out.println("2. Search by Author");
        System.out.print("Choose search type: ");
        
        int choice = getIntInput(scanner);
        scanner.nextLine();
        
        System.out.print("Enter search keyword: ");
        String keyword = scanner.nextLine();
        
        List<Book> results = new ArrayList<>();
        
        if (choice == 1) {
            for (Book book : books) {
                if (book.getTitle().toLowerCase().contains(keyword.toLowerCase())) {
                    results.add(book);
                }
            }
        } else if (choice == 2) {
            for (Book book : books) {
                if (book.getAuthor().toLowerCase().contains(keyword.toLowerCase())) {
                    results.add(book);
                }
            }
        } else {
            System.out.println("Invalid choice!");
            return;
        }
        
        if (results.isEmpty()) {
            System.out.println("No books found!");
        } else {
            System.out.println("Found " + results.size() + " book(s):");
            for (int i = 0; i < results.size(); i++) {
                System.out.print((i + 1) + ". ");
                results.get(i).displayInfo();
            }
        }
    }
    
    public void sortBooks(Scanner scanner) {
        System.out.println("\n=== Sort Books ===");
        System.out.println("1. Sort by Title");
        System.out.println("2. Sort by Author");
        System.out.print("Choose sort type: ");
        
        int choice = getIntInput(scanner);
        
        List<Book> sortedBooks = new ArrayList<>(books);
        
        if (choice == 1) {
            sortedBooks.sort((b1, b2) -> b1.getTitle().compareTo(b2.getTitle()));
        } else if (choice == 2) {
            sortedBooks.sort((b1, b2) -> b1.getAuthor().compareTo(b2.getAuthor()));
        } else {
            System.out.println("Invalid choice!");
            return;
        }
        
        System.out.println("\nSorted Books:");
        for (int i = 0; i < sortedBooks.size(); i++) {
            System.out.print((i + 1) + ". ");
            sortedBooks.get(i).displayInfo();
        }
    }
    
    public boolean borrowBook(int bookId, Mahasiswa mahasiswa) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                return book.borrowBook(mahasiswa);
            }
        }
        return false;
    }
    
    public boolean returnBook(int bookId, Mahasiswa mahasiswa) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                return book.returnBook(mahasiswa);
            }
        }
        return false;
    }
    
    public void viewBorrowers() {
        System.out.println("\n=== Current Borrowers ===");
        boolean found = false;
        
        for (Book book : books) {
            if (!book.isAvailable()) {
                System.out.println("Book: " + book.getTitle() + 
                                 " | Borrower: " + book.getBorrowerName() +
                                 " | NIM: " + book.getBorrowNIM());
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No books are currently borrowed.");
        }
    }
    
    public void viewMyBorrowedBooks(String nim) {
        System.out.println("\n=== My Borrowed Books ===");
        boolean found = false;
        
        for (Book book : books) {
            if (!book.isAvailable() && book.getBorrowNIM() != null && 
                book.getBorrowNIM().equals(nim)) {
                System.out.println("Book ID: " + book.getBookId() + 
                                 " | Title: " + book.getTitle() +
                                 " | Author: " + book.getAuthor());
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("You haven't borrowed any books.");
        }
    }
    
    public void codBlock(Book book) {
        System.out.println("Book blocked: " + book.getTitle());
    }
    
    private int getIntInput(Scanner scanner) {
        try {
            int value = scanner.nextInt();
            scanner.nextLine();
            return value;
        } catch (Exception e) {
            scanner.nextLine();
            return -1;
        }
    }
}