import java.util.*;

public class Main {
    private static Library library = new Library();
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\n=== Library Management System ===");
            System.out.println("1. Login");
            System.out.println("2. Exit");
            System.out.print("Choose option: ");
            
            int mainChoice = getIntInput(scanner);
            
            if (mainChoice == 1) {
                loginScreen(scanner);
            } else if (mainChoice == 2) {
                System.out.println("Thank you");
                scanner.close();
                return;
            } else {
                System.out.println("Invalid choice!");
            }
        }
    }
    
    private static void loginScreen(Scanner scanner) {
        System.out.println("\n=== Login ===");
        System.out.println("1. Admin");
        System.out.println("2. Mahasiswa");
        System.out.println("3. Back to Main Menu");
        System.out.print("Choose option: ");
        
        int userType = getIntInput(scanner);
        
        User user = null;
        
        if (userType == 1) {
            System.out.print("Enter admin name: ");
            String name = scanner.nextLine();
            System.out.print("Enter admin ID: ");
            int adminId = getIntInput(scanner);
            user = new Admin(adminId, name);
        } else if (userType == 2) {
            System.out.print("Enter your name: ");
            String name = scanner.nextLine();
            System.out.print("Enter your NIM: ");
            String nim = scanner.nextLine();
            user = new Mahasiswa(nim, name);
        } else if (userType == 3) {
            return;
        } else {
            System.out.println("Invalid choice!");
            return;
        }
        
        user.accessLibrary(library, scanner);
    }
    
    private static int getIntInput(Scanner scanner) {
        while (true) {
            try {
                int value = scanner.nextInt();
                scanner.nextLine();
                return value;
            } catch (Exception e) {
                System.out.println("Invalid input! Please enter a number.");
                scanner.nextLine();
            }
        }
    }
}