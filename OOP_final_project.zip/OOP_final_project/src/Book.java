public class Book {
    private int bookId;
    private String title;
    private String author;
    private boolean isAvailable;
    private String borrowNIM;
    private String borrowerName;
    
    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }
    
    public void displayInfo() {
        String status = isAvailable ? "Available" : 
                       "Borrowed by: " + borrowerName + " (NIM: " + borrowNIM + ")";
        System.out.println("ID: " + bookId + 
                         " | Title: " + title + 
                         " | Author: " + author + 
                         " | Status: " + status);
    }
    
    // Getters
    public int getBookId() { 
        return bookId; 
    }
    
    public String getTitle() { 
        return title; 
    }
    
    public String getAuthor() { 
        return author; 
    }
    
    public boolean isAvailable() { 
        return isAvailable; 
    }
    
    public String getBorrowNIM() { 
        return borrowNIM; 
    }
    
    public String getBorrowerName() { 
        return borrowerName; 
    }
    
    // Setters
    public void setTitle(String title) {
        this.title = title;
    }
    
    public void setAuthor(String author) {
        this.author = author;
    }
    
    // Borrow and return methods (from UML)
    public void borrow() {
        // Empty method to match UML
    }
    
    public void returnBook() {
        // Empty method to match UML
    }
    
    // Actual implementation methods
    public boolean borrowBook(Mahasiswa mahasiswa) {
        if (isAvailable) {
            this.borrowNIM = mahasiswa.getNim();
            this.borrowerName = mahasiswa.getName();
            this.isAvailable = false;
            return true;
        }
        return false;
    }
    
    public boolean returnBook(Mahasiswa mahasiswa) {
        if (!isAvailable && this.borrowNIM != null && 
            this.borrowNIM.equals(mahasiswa.getNim())) {
            this.borrowNIM = null;
            this.borrowerName = null;
            this.isAvailable = true;
            return true;
        }
        return false;
    }
}