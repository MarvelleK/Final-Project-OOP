import java.util.Scanner;

public class Mahasiswa extends User {
    private String nim;
    
    public Mahasiswa(String nim, String name) {
        super(name);
        this.nim = nim;
    }
    
    public void accessLibrary(Library library, Scanner scanner) {
        System.out.println("\nLog in as Mahasiswa: " + name + " (NIM: " + nim + ")");
        
        while (true) {
            System.out.println("\n=== Mahasiswa Menu ===");
            System.out.println("1. View Available Books");
            System.out.println("2. Search Book");
            System.out.println("3. Sort Books");
            System.out.println("4. Borrow Book");
            System.out.println("5. Return Book");
            System.out.println("6. Logout");
            System.out.print("Choose option: ");
            
            int choice = getIntInput(scanner);
            
            switch (choice) {
                case 1 -> library.viewAvailableBooks();
                case 2 -> library.searchBook(scanner);
                case 3 -> library.sortBooks(scanner);
                case 4 -> borrowBook(library, scanner);
                case 5 -> returnBook(library, scanner);
                case 6 -> {
                    System.out.println("Logged out");
                    return;
                }
                default -> System.out.println("Invalid choice!");
            }
        }
    }
    
    public boolean borrowedBook(Library library, int bookId) {
        return library.borrowBook(bookId, this);
    }
    
    private void borrowBook(Library library, Scanner scanner) {
        System.out.print("Enter Book ID to borrow: ");
        int bookId = getIntInput(scanner);
        boolean success = borrowedBook(library, bookId);
        
        if (success) {
            System.out.println("Book borrowed successfully!");
        } else {
            System.out.println("Failed to borrow book!");
        }
    }
    
    public boolean returnBook(Library library, int bookId) {
        return library.returnBook(bookId, this);
    }
    
    private void returnBook(Library library, Scanner scanner) {
        System.out.print("Enter Book ID to return: ");
        int bookId = getIntInput(scanner);
        boolean success = returnBook(library, bookId);
        
        if (success) {
            System.out.println("Book returned successfully!");
        } else {
            System.out.println("Failed to return book!");
        }
    }
    
    public String getNim() {
        return nim;
    }
    
    private int getIntInput(Scanner scanner) {
        try {
            int value = scanner.nextInt();
            scanner.nextLine();
            return value;
        } catch (Exception e) {
            scanner.nextLine();
            return -1;
        }
    }
}